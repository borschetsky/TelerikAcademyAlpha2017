﻿namespace Dealership.Contracts
{
    public interface IMotorcycle
    {
        string Category { get; }
    }
}
